public interface IsDamagable
{
    void TakeDamage();
}

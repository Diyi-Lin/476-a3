using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class Rocks : MonoBehaviour
{
    PhotonView PV;

    private void Awake()
    {
        PV = GetComponent<PhotonView>();
    }
    public void Destory()
    {
        PV.RPC("Destroy_RPC", RpcTarget.AllViaServer);
    }

    [PunRPC]
    void Destroy_RPC()
    {
        Destroy(this.gameObject);
    }
}

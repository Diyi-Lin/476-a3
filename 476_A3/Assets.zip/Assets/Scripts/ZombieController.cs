using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class ZombieController : MonoBehaviour
{
    [SerializeField] GameObject TankTurret;
    [SerializeField] GameObject ShootPoint;
    public float countDownToShoot = 4;
    [SerializeField] AiAgent ai;
    Transform target;
    float countDown = 3.0f;

    public Rigidbody m_Shell;

    public AudioSource m_ShootingAudio;         // Reference to the audio source used to play the shooting audio. NB: different to the movement audio source.
    public AudioClip m_FireClip;                // Audio that plays when each shot is fired.
    public void Update()
    {
        countDownToShoot -= 1.0f*Time.deltaTime;
        if (countDownToShoot <= 0)
        {
            Shoot();
            countDownToShoot = 3;
        }
        countDown -= 1.0f * Time.deltaTime;
        if (countDown <= 0)
        {
            FindTarget();
            countDown = 16;
        }


    }

    void Shoot()
    {
        Rigidbody shellInstance = Instantiate(m_Shell, ShootPoint.transform.position, TankTurret.transform.rotation);

        shellInstance.velocity = 25f * TankTurret.transform.forward;

        m_ShootingAudio.clip = m_FireClip;
        m_ShootingAudio.Play();
    }

    public void FindTarget()
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        target = players[Random.Range(0, players.Length)].transform;
        ai.trackedTarget = target;
    }
}
